// Mesin audio duplex latensi rendah: mic/line-in -> compressor -> limiter -> output.
// Memakai Oboe (AAudio di Android 8.1+, OpenSL ES di bawahnya).

#include <android/log.h>
#include <jni.h>
#include <oboe/Oboe.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <memory>
#include <mutex>
#include <vector>

#include "compressor.h"

#define LOG_TAG "DbxComp"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

enum ParamId {
    P_THRESH = 0,
    P_RATIO,
    P_ATTACK,
    P_RELEASE,
    P_KNEE,
    P_MAKEUP,
    P_CEIL,
    P_LIM_ON,
    P_BYPASS,
    P_IN_GAIN,
    P_OUT_GAIN,
    P_COUNT
};

class Engine : public oboe::AudioStreamDataCallback,
               public oboe::AudioStreamErrorCallback,
               public std::enable_shared_from_this<Engine> {
public:
    Engine() {
        const float defaults[P_COUNT] = {-20.f, 4.f, 10.f, 200.f, 6.f, 0.f,
                                         -1.f,  1.f, 0.f,  0.f,   0.f};
        for (int i = 0; i < P_COUNT; ++i) params[i].store(defaults[i]);
    }

    void setParam(int id, float v) {
        if (id >= 0 && id < P_COUNT) params[id].store(v, std::memory_order_relaxed);
    }

    void getMeters(float* out3) {
        out3[0] = meterIn.exchange(-100.f);
        out3[1] = meterOut.exchange(-100.f);
        out3[2] = meterGr.exchange(0.f);
    }

    bool start(int inId, int outId) {
        std::lock_guard<std::mutex> lock(mtx);
        inputDeviceId = inId;
        outputDeviceId = outId;
        running = true;
        if (!openStreams()) {
            running = false;
            return false;
        }
        return true;
    }

    void stop() {
        std::lock_guard<std::mutex> lock(mtx);
        running = false;
        closeStreams();
    }

    oboe::DataCallbackResult onAudioReady(oboe::AudioStream* stream, void* audioData,
                                          int32_t numFrames) override {
        float* out = static_cast<float*>(audioData);
        const int outCh = stream->getChannelCount();

        // Baca input tanpa blocking (timeout 0). Kekurangan data diisi nol.
        int32_t got = 0;
        oboe::AudioStream* in = inStream.get();
        const int32_t frames = std::min<int32_t>(numFrames, (int32_t)inBuf.size());
        if (in != nullptr && frames > 0) {
            auto res = in->read(inBuf.data(), frames, 0);
            if (res.error() == oboe::Result::OK) got = res.value();
        }

        CompParams cp;
        cp.thresholdDb = params[P_THRESH].load(std::memory_order_relaxed);
        cp.ratio = params[P_RATIO].load(std::memory_order_relaxed);
        cp.attackMs = params[P_ATTACK].load(std::memory_order_relaxed);
        cp.releaseMs = params[P_RELEASE].load(std::memory_order_relaxed);
        cp.kneeDb = params[P_KNEE].load(std::memory_order_relaxed);
        cp.makeupDb = params[P_MAKEUP].load(std::memory_order_relaxed);
        const float ceilDb = params[P_CEIL].load(std::memory_order_relaxed);
        const bool limOn = params[P_LIM_ON].load(std::memory_order_relaxed) > 0.5f;
        const bool bypass = params[P_BYPASS].load(std::memory_order_relaxed) > 0.5f;
        const float inG = dbToLin(params[P_IN_GAIN].load(std::memory_order_relaxed));
        const float outG = dbToLin(params[P_OUT_GAIN].load(std::memory_order_relaxed));

        comp.prepare(sampleRate, cp);
        lim.prepare(sampleRate, ceilDb);

        float inPeak = 0.f, outPeak = 0.f, maxReduction = 0.f;

        for (int32_t i = 0; i < numFrames; ++i) {
            const float raw = (i < got) ? inBuf[i] : 0.f;
            const float x = raw * inG;
            float y;
            if (bypass) {
                y = x;
            } else {
                y = x * comp.process(x, cp);
                float red = -comp.gr;
                if (limOn) {
                    y = lim.process(y);
                    red += -lim.gr;
                }
                y *= outG;
                maxReduction = std::max(maxReduction, red);
            }
            y = std::max(-1.f, std::min(1.f, y));  // jangan pernah clip digital di output

            inPeak = std::max(inPeak, std::fabs(x));
            outPeak = std::max(outPeak, std::fabs(y));
            for (int c = 0; c < outCh; ++c) out[i * outCh + c] = y;
        }

        publishMax(meterIn, 20.f * std::log10(inPeak + 1e-6f));
        publishMax(meterOut, 20.f * std::log10(outPeak + 1e-6f));
        publishMax(meterGr, maxReduction);
        return oboe::DataCallbackResult::Continue;
    }

    // Dipanggil Oboe di thread terpisah kalau perangkat audio terputus (mis. USB dicabut).
    void onErrorAfterClose(oboe::AudioStream*, oboe::Result error) override {
        if (error != oboe::Result::ErrorDisconnected) return;
        std::lock_guard<std::mutex> lock(mtx);
        if (running) openStreams();
    }

private:
    static void publishMax(std::atomic<float>& a, float v) {
        if (v > a.load(std::memory_order_relaxed)) a.store(v, std::memory_order_relaxed);
    }

    bool openStreams() {
        closeStreams();

        oboe::AudioStreamBuilder ob;
        ob.setDirection(oboe::Direction::Output)
            ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
            ->setSharingMode(oboe::SharingMode::Exclusive)
            ->setFormat(oboe::AudioFormat::Float)
            ->setChannelCount(oboe::ChannelCount::Stereo)
            ->setUsage(oboe::Usage::Media)
            ->setDeviceId(outputDeviceId)
            ->setDataCallback(shared_from_this())
            ->setErrorCallback(shared_from_this());
        oboe::Result r = ob.openStream(outStream);
        if (r != oboe::Result::OK) {
            LOGE("Gagal membuka output: %s", oboe::convertToText(r));
            outStream.reset();
            return false;
        }
        outStream->setBufferSizeInFrames(outStream->getFramesPerBurst() * 2);
        sampleRate = static_cast<float>(outStream->getSampleRate());

        oboe::AudioStreamBuilder ib;
        ib.setDirection(oboe::Direction::Input)
            ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
            ->setSharingMode(oboe::SharingMode::Exclusive)
            ->setFormat(oboe::AudioFormat::Float)
            ->setChannelCount(oboe::ChannelCount::Mono)
            ->setSampleRate(outStream->getSampleRate())
            ->setSampleRateConversionQuality(oboe::SampleRateConversionQuality::Medium)
            ->setInputPreset(oboe::InputPreset::Unprocessed)  // matikan AGC/noise suppression
            ->setDeviceId(inputDeviceId);
        r = ib.openStream(inStream);
        if (r != oboe::Result::OK) {
            LOGE("Gagal membuka input: %s", oboe::convertToText(r));
            inStream.reset();
            outStream->close();
            outStream.reset();
            return false;
        }

        inBuf.assign(std::max<int32_t>(8192, outStream->getFramesPerBurst() * 8), 0.f);
        comp.reset();
        lim.reset();

        inStream->requestStart();
        outStream->requestStart();
        return true;
    }

    void closeStreams() {
        // Output ditutup lebih dulu supaya callback berhenti sebelum input dilepas.
        if (outStream) {
            outStream->stop();
            outStream->close();
            outStream.reset();
        }
        if (inStream) {
            inStream->stop();
            inStream->close();
            inStream.reset();
        }
    }

    std::mutex mtx;
    bool running = false;
    int inputDeviceId = 0;
    int outputDeviceId = 0;
    float sampleRate = 48000.f;

    std::shared_ptr<oboe::AudioStream> outStream;
    std::shared_ptr<oboe::AudioStream> inStream;
    std::vector<float> inBuf;

    std::atomic<float> params[P_COUNT];
    std::atomic<float> meterIn{-100.f};
    std::atomic<float> meterOut{-100.f};
    std::atomic<float> meterGr{0.f};

    Compressor comp;
    Limiter lim;
};

static std::shared_ptr<Engine> gEngine;

static Engine& engine() {
    if (!gEngine) gEngine = std::make_shared<Engine>();
    return *gEngine;
}

extern "C" {

JNIEXPORT jboolean JNICALL Java_com_example_dbxcomp_AudioEngine_nativeStart(
    JNIEnv*, jobject, jint inputDeviceId, jint outputDeviceId) {
    return engine().start(inputDeviceId, outputDeviceId) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL Java_com_example_dbxcomp_AudioEngine_nativeStop(JNIEnv*, jobject) {
    engine().stop();
}

JNIEXPORT void JNICALL Java_com_example_dbxcomp_AudioEngine_nativeSetParam(
    JNIEnv*, jobject, jint id, jfloat value) {
    engine().setParam(id, value);
}

JNIEXPORT void JNICALL Java_com_example_dbxcomp_AudioEngine_nativeGetMeters(
    JNIEnv* env, jobject, jfloatArray out) {
    jfloat tmp[3];
    engine().getMeters(tmp);
    env->SetFloatArrayRegion(out, 0, 3, tmp);
}

}  // extern "C"
