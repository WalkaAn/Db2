// Mesin audio duplex latensi rendah: mic/line-in (mono atau stereo) -> compressor ->
// limiter -> output stereo. Memakai Oboe (AAudio di Android 8.1+, OpenSL ES di bawahnya).

#include <android/log.h>
#include <jni.h>
#include <oboe/Oboe.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <memory>
#include <mutex>
#include <vector>

#include "compressor.h"
#include "ring_buffer.h"

#define LOG_TAG "DbxComp"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

enum ParamId {
    P_THRESH = 0,
    P_RATIO,
    P_ATTACK,
    P_RELEASE,
    P_KNEE,
    P_MAKEUP,
    P_CEIL,
    P_LIM_ON,
    P_BYPASS,
    P_IN_GAIN,
    P_OUT_GAIN,
    P_LINK,
    P_COUNT
};

class Engine : public oboe::AudioStreamDataCallback,
               public oboe::AudioStreamErrorCallback,
               public std::enable_shared_from_this<Engine> {
public:
    Engine() {
        const float defaults[P_COUNT] = {-20.f, 4.f, 10.f, 200.f, 6.f, 0.f,
                                         -1.f,  1.f, 0.f,  0.f,   0.f, 1.f};
        for (int i = 0; i < P_COUNT; ++i) params[i].store(defaults[i]);
    }

    void setParam(int id, float v) {
        if (id >= 0 && id < P_COUNT) params[id].store(v, std::memory_order_relaxed);
    }

    void setRecording(bool on) {
        if (on) ring.clear();  // thread audio belum menulis karena flag masih false
        recording.store(on, std::memory_order_relaxed);
    }

    int readRecorded(float* out, int maxFloats) {
        return static_cast<int>(ring.read(out, static_cast<size_t>(std::max(0, maxFloats))));
    }

    int getSampleRate() const { return static_cast<int>(sampleRate); }

    // Jumlah channel input yang benar-benar diberikan perangkat (1 atau 2).
    int getInputChannels() const { return inChannels.load(std::memory_order_relaxed); }

    void getMeters(float* out3) {
        out3[0] = meterIn.exchange(-100.f);
        out3[1] = meterOut.exchange(-100.f);
        out3[2] = meterGr.exchange(0.f);
    }

    bool start(int inId, int outId, bool stereo) {
        std::lock_guard<std::mutex> lock(mtx);
        inputDeviceId = inId;
        outputDeviceId = outId;
        wantStereo = stereo;
        running = true;
        if (!openStreams()) {
            running = false;
            return false;
        }
        return true;
    }

    void stop() {
        std::lock_guard<std::mutex> lock(mtx);
        running = false;
        closeStreams();
    }

    oboe::DataCallbackResult onAudioReady(oboe::AudioStream* stream, void* audioData,
                                          int32_t numFrames) override {
        float* out = static_cast<float*>(audioData);
        const int outCh = stream->getChannelCount();
        const int inCh = std::max(1, inChannels.load(std::memory_order_relaxed));
        const bool stereo = inCh >= 2;

        // Baca input tanpa blocking (timeout 0). Kekurangan data diisi nol.
        int32_t got = 0;
        oboe::AudioStream* in = inStream.get();
        const int32_t frames = std::min<int32_t>(numFrames, (int32_t)(inBuf.size() / inCh));
        if (in != nullptr && frames > 0) {
            auto res = in->read(inBuf.data(), frames, 0);
            if (res.error() == oboe::Result::OK) got = res.value();
        }

        ProcParams pp;
        pp.comp.thresholdDb = params[P_THRESH].load(std::memory_order_relaxed);
        pp.comp.ratio = params[P_RATIO].load(std::memory_order_relaxed);
        pp.comp.attackMs = params[P_ATTACK].load(std::memory_order_relaxed);
        pp.comp.releaseMs = params[P_RELEASE].load(std::memory_order_relaxed);
        pp.comp.kneeDb = params[P_KNEE].load(std::memory_order_relaxed);
        pp.comp.makeupDb = params[P_MAKEUP].load(std::memory_order_relaxed);
        pp.ceilDb = params[P_CEIL].load(std::memory_order_relaxed);
        pp.limOn = params[P_LIM_ON].load(std::memory_order_relaxed) > 0.5f;
        pp.link = params[P_LINK].load(std::memory_order_relaxed) > 0.5f;
        pp.outGain = dbToLin(params[P_OUT_GAIN].load(std::memory_order_relaxed));
        const bool bypass = params[P_BYPASS].load(std::memory_order_relaxed) > 0.5f;
        const float inG = dbToLin(params[P_IN_GAIN].load(std::memory_order_relaxed));

        chain.prepare(sampleRate, pp);

        float inPeak = 0.f, outPeak = 0.f, maxReduction = 0.f;
        const bool rec = recording.load(std::memory_order_relaxed);

        for (int32_t i = 0; i < numFrames; ++i) {
            const bool have = i < got;
            const float rawL = have ? inBuf[i * inCh] : 0.f;
            const float rawR = (have && stereo) ? inBuf[i * inCh + 1] : rawL;
            const float l = rawL * inG;
            const float r = rawR * inG;

            float yl, yr;
            if (bypass) {
                yl = l;
                yr = stereo ? r : l;
            } else {
                float red = 0.f;
                chain.process(l, r, stereo, pp, yl, yr, red);
                maxReduction = std::max(maxReduction, red);
            }
            yl = std::max(-1.f, std::min(1.f, yl));  // jangan pernah clip digital di output
            yr = std::max(-1.f, std::min(1.f, yr));

            // Rekaman: stereo -> (kiri, kanan) hasil; mono -> (asli, hasil).
            if (rec) {
                if (stereo) ring.push2(yl, yr);
                else ring.push2(l, yl);
            }

            inPeak = std::max(inPeak, std::max(std::fabs(l), stereo ? std::fabs(r) : 0.f));
            outPeak = std::max(outPeak, std::max(std::fabs(yl), std::fabs(yr)));
            for (int c = 0; c < outCh; ++c) out[i * outCh + c] = (c == 0) ? yl : yr;
        }

        publishMax(meterIn, 20.f * std::log10(inPeak + 1e-6f));
        publishMax(meterOut, 20.f * std::log10(outPeak + 1e-6f));
        publishMax(meterGr, maxReduction);
        return oboe::DataCallbackResult::Continue;
    }

    // Dipanggil Oboe di thread terpisah kalau perangkat audio terputus (mis. USB dicabut).
    void onErrorAfterClose(oboe::AudioStream*, oboe::Result error) override {
        if (error != oboe::Result::ErrorDisconnected) return;
        std::lock_guard<std::mutex> lock(mtx);
        if (running) openStreams();
    }

private:
    static void publishMax(std::atomic<float>& a, float v) {
        if (v > a.load(std::memory_order_relaxed)) a.store(v, std::memory_order_relaxed);
    }

    bool openInput(int channels) {
        oboe::AudioStreamBuilder ib;
        ib.setDirection(oboe::Direction::Input)
            ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
            ->setSharingMode(oboe::SharingMode::Exclusive)
            ->setFormat(oboe::AudioFormat::Float)
            ->setChannelCount(channels)
            ->setSampleRate(outStream->getSampleRate())
            ->setSampleRateConversionQuality(oboe::SampleRateConversionQuality::Medium)
            // Stereo: preset Camcorder (jalur yang dipakai kamera untuk dua mic).
            // Mono: Unprocessed (matikan AGC/noise suppression).
            ->setInputPreset(channels == 2 ? oboe::InputPreset::Camcorder
                                           : oboe::InputPreset::Unprocessed)
            ->setDeviceId(inputDeviceId);
        const oboe::Result r = ib.openStream(inStream);
        if (r != oboe::Result::OK) {
            LOGE("Gagal membuka input %d channel: %s", channels, oboe::convertToText(r));
            inStream.reset();
            return false;
        }
        return true;
    }

    bool openStreams() {
        closeStreams();

        oboe::AudioStreamBuilder ob;
        ob.setDirection(oboe::Direction::Output)
            ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
            ->setSharingMode(oboe::SharingMode::Exclusive)
            ->setFormat(oboe::AudioFormat::Float)
            ->setChannelCount(oboe::ChannelCount::Stereo)
            ->setUsage(oboe::Usage::Media)
            ->setDeviceId(outputDeviceId)
            ->setDataCallback(shared_from_this())
            ->setErrorCallback(shared_from_this());
        oboe::Result r = ob.openStream(outStream);
        if (r != oboe::Result::OK) {
            LOGE("Gagal membuka output: %s", oboe::convertToText(r));
            outStream.reset();
            return false;
        }
        outStream->setBufferSizeInFrames(outStream->getFramesPerBurst() * 2);
        sampleRate = static_cast<float>(outStream->getSampleRate());

        // Coba stereo dulu kalau diminta; kalau perangkat menolak, turun ke mono.
        bool inOk = false;
        if (wantStereo) inOk = openInput(2);
        if (!inOk) inOk = openInput(1);
        if (!inOk) {
            outStream->close();
            outStream.reset();
            return false;
        }
        inChannels.store(std::max(1, inStream->getChannelCount()));

        inBuf.assign(static_cast<size_t>(std::max<int32_t>(8192, outStream->getFramesPerBurst() * 8)) *
                         static_cast<size_t>(inChannels.load()),
                     0.f);
        chain.reset();

        inStream->requestStart();
        outStream->requestStart();
        return true;
    }

    void closeStreams() {
        // Output ditutup lebih dulu supaya callback berhenti sebelum input dilepas.
        if (outStream) {
            outStream->stop();
            outStream->close();
            outStream.reset();
        }
        if (inStream) {
            inStream->stop();
            inStream->close();
            inStream.reset();
        }
    }

    std::mutex mtx;
    bool running = false;
    bool wantStereo = false;
    int inputDeviceId = 0;
    int outputDeviceId = 0;
    float sampleRate = 48000.f;
    std::atomic<int> inChannels{1};

    std::shared_ptr<oboe::AudioStream> outStream;
    std::shared_ptr<oboe::AudioStream> inStream;
    std::vector<float> inBuf;

    std::atomic<float> params[P_COUNT];
    std::atomic<float> meterIn{-100.f};
    std::atomic<float> meterOut{-100.f};
    std::atomic<float> meterGr{0.f};

    RingBuffer ring;
    std::atomic<bool> recording{false};

    StereoChain chain;
};

static std::shared_ptr<Engine> gEngine;

static Engine& engine() {
    if (!gEngine) gEngine = std::make_shared<Engine>();
    return *gEngine;
}

extern "C" {

JNIEXPORT jboolean JNICALL Java_com_example_dbxcomp_AudioEngine_nativeStart(
    JNIEnv*, jobject, jint inputDeviceId, jint outputDeviceId, jboolean stereo) {
    return engine().start(inputDeviceId, outputDeviceId, stereo == JNI_TRUE) ? JNI_TRUE
                                                                             : JNI_FALSE;
}

JNIEXPORT void JNICALL Java_com_example_dbxcomp_AudioEngine_nativeStop(JNIEnv*, jobject) {
    engine().stop();
}

JNIEXPORT void JNICALL Java_com_example_dbxcomp_AudioEngine_nativeSetParam(
    JNIEnv*, jobject, jint id, jfloat value) {
    engine().setParam(id, value);
}

JNIEXPORT void JNICALL Java_com_example_dbxcomp_AudioEngine_nativeGetMeters(
    JNIEnv* env, jobject, jfloatArray out) {
    jfloat tmp[3];
    engine().getMeters(tmp);
    env->SetFloatArrayRegion(out, 0, 3, tmp);
}

JNIEXPORT void JNICALL Java_com_example_dbxcomp_AudioEngine_nativeSetRecording(
    JNIEnv*, jobject, jboolean on) {
    engine().setRecording(on == JNI_TRUE);
}

JNIEXPORT jint JNICALL Java_com_example_dbxcomp_AudioEngine_nativeReadRecorded(
    JNIEnv* env, jobject, jfloatArray out) {
    const jsize cap = env->GetArrayLength(out);
    jfloat* p = env->GetFloatArrayElements(out, nullptr);
    if (p == nullptr) return 0;
    const int n = engine().readRecorded(p, cap);
    env->ReleaseFloatArrayElements(out, p, 0);
    return n;
}

JNIEXPORT jint JNICALL Java_com_example_dbxcomp_AudioEngine_nativeGetSampleRate(
    JNIEnv*, jobject) {
    return engine().getSampleRate();
}

JNIEXPORT jint JNICALL Java_com_example_dbxcomp_AudioEngine_nativeGetInputChannels(
    JNIEnv*, jobject) {
    return engine().getInputChannels();
}

}  // extern "C"
