#pragma once
// DSP inti: compressor (RMS detector, soft knee ala "OverEasy") + limiter (peak).
// Semua gain dihitung dalam dB, dihaluskan dengan attack/release satu kutub.

#include <algorithm>
#include <cmath>

inline float dbToLin(float db) { return std::exp(db * 0.11512925f); }  // ln(10)/20

struct CompParams {
    float thresholdDb = -20.f;
    float ratio = 4.f;
    float attackMs = 10.f;
    float releaseMs = 200.f;
    float kneeDb = 6.f;
    float makeupDb = 0.f;
};

class Compressor {
public:
    float gr = 0.f;  // gain reduction saat ini dalam dB (<= 0)

    void reset() {
        ms = 0.f;
        gr = 0.f;
    }

    void prepare(float sampleRate, const CompParams& p) {
        atk = std::exp(-1.f / (std::max(p.attackMs, 0.05f) * 0.001f * sampleRate));
        rel = std::exp(-1.f / (std::max(p.releaseMs, 1.f) * 0.001f * sampleRate));
        rmsCoef = std::exp(-1.f / (0.005f * sampleRate));  // jendela RMS ~5 ms
    }

    // Mengembalikan gain linear (sudah termasuk makeup) untuk sampel x.
    float process(float x, const CompParams& p) {
        ms = rmsCoef * ms + (1.f - rmsCoef) * x * x;
        const float levelDb = 10.f * std::log10(ms + 1e-12f);
        const float over = levelDb - p.thresholdDb;
        const float slope = 1.f / std::max(p.ratio, 1.f) - 1.f;  // <= 0
        const float knee = p.kneeDb;

        float target;  // perubahan gain yang diinginkan (dB, <= 0)
        if (knee < 0.1f) {
            target = over > 0.f ? slope * over : 0.f;  // hard knee
        } else {
            const float half = 0.5f * knee;
            if (over <= -half) {
                target = 0.f;
            } else if (over >= half) {
                target = slope * over;
            } else {
                const float t = over + half;
                target = slope * t * t / (2.f * knee);  // soft knee
            }
        }

        gr = (target < gr) ? atk * gr + (1.f - atk) * target
                           : rel * gr + (1.f - rel) * target;
        return dbToLin(gr + p.makeupDb);
    }

private:
    float ms = 0.f, atk = 0.f, rel = 0.f, rmsCoef = 0.f;
};

class Limiter {
public:
    float gr = 0.f;  // dB (<= 0)

    void reset() { gr = 0.f; }

    void prepare(float sampleRate, float ceilingDb) {
        ceilDb = ceilingDb;
        ceilLin = dbToLin(ceilingDb);
        atk = std::exp(-1.f / (0.0005f * sampleRate));  // 0.5 ms
        rel = std::exp(-1.f / (0.080f * sampleRate));   // 80 ms
    }

    float process(float x) {
        const float a = std::fabs(x) + 1e-9f;
        const float db = 20.f * std::log10(a);
        const float target = db > ceilDb ? ceilDb - db : 0.f;
        gr = (target < gr) ? atk * gr + (1.f - atk) * target
                           : rel * gr + (1.f - rel) * target;
        const float y = x * dbToLin(gr);
        // Pengaman terakhir: tanpa lookahead, puncak sangat cepat bisa lolos
        // sesaat, jadi dipotong keras di ceiling.
        return std::max(-ceilLin, std::min(ceilLin, y));
    }

private:
    float ceilDb = -1.f, ceilLin = 0.891f, atk = 0.f, rel = 0.f;
};
