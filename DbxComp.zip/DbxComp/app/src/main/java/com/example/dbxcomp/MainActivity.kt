package com.example.dbxcomp

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.pow

/** Bar meter horizontal sederhana. */
class MeterView(
    context: Context,
    private val minValue: Float,
    private val maxValue: Float,
    private val baseColor: Int,
    private val redAbove: Float? = null
) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    var value: Float = minValue
        set(v) {
            field = v
            invalidate()
        }

    override fun onDraw(canvas: Canvas) {
        paint.color = Color.rgb(40, 46, 54)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        val frac = ((value - minValue) / (maxValue - minValue)).coerceIn(0f, 1f)
        paint.color =
            if (redAbove != null && value > redAbove) Color.rgb(230, 70, 60) else baseColor
        canvas.drawRect(0f, 0f, width * frac, height.toFloat(), paint)
    }
}

class MainActivity : Activity() {

    private companion object {
        const val CHANNEL_HINT =
            "Berlaku saat START. Stereo asli hanya jika HP atau interface memberi 2 channel."
    }

    private val handler = Handler(Looper.getMainLooper())
    private val meters = FloatArray(3)

    // Nilai terkini tiap parameter (NaN = belum diset) dan fungsi untuk mengubahnya dari preset.
    private val values = FloatArray(AudioEngine.P_LINK + 1) { Float.NaN }
    private val setters = arrayOfNulls<(Float) -> Unit>(AudioEngine.P_LINK + 1)

    private lateinit var prefs: SharedPreferences
    private lateinit var recorder: WavRecorder

    private lateinit var meterIn: MeterView
    private lateinit var meterOut: MeterView
    private lateinit var meterGr: MeterView
    private lateinit var startButton: Button
    private lateinit var recordButton: Button
    private lateinit var abSwitch: Switch
    private lateinit var stereoSwitch: Switch
    private lateinit var channelText: TextView
    private lateinit var statusText: TextView
    private lateinit var inSpinner: Spinner
    private lateinit var outSpinner: Spinner
    private lateinit var presetSpinner: Spinner

    private var inDevices: List<AudioDeviceInfo?> = emptyList()
    private var outDevices: List<AudioDeviceInfo?> = emptyList()
    private var running = false

    private val ticker = object : Runnable {
        override fun run() {
            AudioEngine.nativeGetMeters(meters)
            meterIn.value = max(meters[0], meterIn.value - 2f)
            meterOut.value = max(meters[1], meterOut.value - 2f)
            meterGr.value = max(meters[2], meterGr.value - 0.8f)
            if (recorder.isRecording) {
                recordButton.text = "■ STOP REKAM  ${formatTime(recorder.elapsedMs)}"
            }
            if (running) handler.postDelayed(this, 33)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        prefs = getSharedPreferences("dbxcomp", Context.MODE_PRIVATE)
        recorder = WavRecorder(this) { location -> onRecordingDone(location) }

        // Pulihkan pengaturan terakhir (bypass sengaja tidak dipulihkan).
        parseValues(prefs.getString("last", null))?.copyInto(values)
        values[AudioEngine.P_BYPASS] = Float.NaN

        val pad = dp(16)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.rgb(16, 20, 24))
            addView(root)
        }
        setContentView(scroll)

        root.addView(label("DbxComp  |  Compressor + Limiter", 20f, Color.WHITE))
        root.addView(
            label(
                "Pakai headphone atau audio interface USB. Mic HP + speaker HP di ruangan " +
                    "yang sama akan menyebabkan feedback (howling). Bluetooth = latensi tinggi.",
                12f, Color.rgb(240, 180, 80)
            )
        )

        // Perangkat audio
        inDevices = deviceList(true)
        outDevices = deviceList(false)
        root.addView(label("Input"))
        inSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                inDevices.map { describe(it) }
            )
        }
        root.addView(inSpinner)
        root.addView(label("Output"))
        outSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                outDevices.map { describe(it) }
            )
        }
        root.addView(outSpinner)

        // Input stereo asli (2 channel). Berlaku saat START.
        stereoSwitch = Switch(this).apply {
            text = "Input stereo (2 mic / 2 channel)"
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("stereo_in", false)
        }
        stereoSwitch.setOnCheckedChangeListener { _, c ->
            prefs.edit().putBoolean("stereo_in", c).apply()
        }
        root.addView(stereoSwitch)
        channelText = label(CHANNEL_HINT, 12f)
        root.addView(channelText)

        // START dan REKAM
        startButton = Button(this).apply { text = "START" }
        startButton.setOnClickListener { if (running) stopAudio() else requestAndStart() }
        recordButton = Button(this).apply { text = "● REKAM" }
        recordButton.setOnClickListener { toggleRecord() }
        val buttonRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttonRow.addView(startButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        buttonRow.addView(recordButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(buttonRow)

        abSwitch = Switch(this).apply {
            text = "Rekam A/B (kiri = asli, kanan = hasil). Untuk dibuka di editor, " +
                "bukan didengar di headphone. Hanya untuk input mono."
            setTextColor(Color.WHITE)
        }
        root.addView(abSwitch)
        statusText = label("Rekaman disimpan di Music/DbxComp (format WAV).", 12f)
        root.addView(statusText)

        // Meter
        val h = dp(14)
        root.addView(label("Input level (dBFS)"))
        meterIn = MeterView(this, -60f, 0f, Color.rgb(60, 200, 120), -3f)
        root.addView(meterIn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h))
        root.addView(label("Gain reduction (dB)"))
        meterGr = MeterView(this, 0f, 20f, Color.rgb(240, 160, 40))
        root.addView(meterGr, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h))
        root.addView(label("Output level (dBFS)"))
        meterOut = MeterView(this, -60f, 0f, Color.rgb(60, 200, 120), -3f)
        root.addView(meterOut, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h))

        // Preset
        root.addView(label("PRESET", 15f, Color.WHITE))
        presetSpinner = Spinner(this)
        root.addView(presetSpinner)
        val presetRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((title, action) in listOf<Pair<String, () -> Unit>>(
            "Muat" to { onLoadClicked() },
            "Simpan" to { onSaveClicked() },
            "Hapus" to { onDeleteClicked() }
        )) {
            val b = Button(this).apply { text = title }
            b.setOnClickListener { action() }
            presetRow.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(presetRow)
        refreshPresets()

        // Kontrol
        root.addView(label("COMPRESSOR", 15f, Color.WHITE))
        addSwitch(root, "Bypass compressor/limiter", AudioEngine.P_BYPASS, false)
        addSwitch(root, "Link L/R (gain reduction sama di kiri-kanan, input stereo)", AudioEngine.P_LINK, true)
        addSlider(root, "Input gain", AudioEngine.P_IN_GAIN, -12f, 24f, 0f, false, "dB", 1)
        addSlider(root, "Threshold", AudioEngine.P_THRESH, -60f, 0f, -20f, false, "dB", 1)
        addSlider(root, "Ratio", AudioEngine.P_RATIO, 1f, 20f, 4f, false, ": 1", 1)
        addSlider(root, "Attack", AudioEngine.P_ATTACK, 0.1f, 100f, 10f, true, "ms", 1)
        addSlider(root, "Release", AudioEngine.P_RELEASE, 10f, 2000f, 200f, true, "ms", 0)
        addSlider(root, "Knee (0 = hard)", AudioEngine.P_KNEE, 0f, 24f, 6f, false, "dB", 1)
        addSlider(root, "Makeup gain", AudioEngine.P_MAKEUP, 0f, 24f, 0f, false, "dB", 1)

        root.addView(label("LIMITER", 15f, Color.WHITE))
        addSwitch(root, "Limiter aktif", AudioEngine.P_LIM_ON, true)
        addSlider(root, "Ceiling", AudioEngine.P_CEIL, -12f, 0f, -1f, false, "dBFS", 1)
        addSlider(root, "Output gain", AudioEngine.P_OUT_GAIN, -24f, 12f, 0f, false, "dB", 1)
    }

    override fun onStop() {
        super.onStop()
        // Simpan pengaturan terakhir.
        prefs.edit().putString("last", formatValues()).apply()
        // Android membatasi mic di latar belakang, jadi hentikan dengan bersih.
        if (running) stopAudio()
    }

    // ---------- Audio ----------

    private fun requestAndStart() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            startAudio()
        } else {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            startAudio()
        } else {
            Toast.makeText(this, "Izin mikrofon diperlukan", Toast.LENGTH_LONG).show()
        }
    }

    private fun startAudio() {
        val inId = inDevices.getOrNull(inSpinner.selectedItemPosition)?.id ?: 0
        val outId = outDevices.getOrNull(outSpinner.selectedItemPosition)?.id ?: 0
        if (AudioEngine.nativeStart(inId, outId, stereoSwitch.isChecked)) {
            running = true
            startButton.text = "STOP"
            val ch = AudioEngine.nativeGetInputChannels()
            abSwitch.isEnabled = ch < 2
            channelText.text = when {
                ch >= 2 -> "Input aktif: stereo asli (2 channel)"
                stereoSwitch.isChecked -> "Input aktif: mono (HP/perangkat tidak memberi 2 channel)"
                else -> "Input aktif: mono"
            }
            handler.post(ticker)
        } else {
            Toast.makeText(this, "Gagal membuka perangkat audio", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopAudio() {
        recorder.stop()  // rekaman diselesaikan dulu di thread latar
        AudioEngine.nativeStop()
        running = false
        startButton.text = "START"
        abSwitch.isEnabled = true
        channelText.text = CHANNEL_HINT
    }

    // ---------- Rekam ----------

    private fun toggleRecord() {
        if (recorder.isRecording) {
            recorder.stop()
            recordButton.text = "Menyimpan..."
            return
        }
        if (!running) {
            Toast.makeText(this, "Tekan START dulu, baru REKAM", Toast.LENGTH_SHORT).show()
            return
        }
        val rate = AudioEngine.nativeGetSampleRate()
        val twoChannels = AudioEngine.nativeGetInputChannels() >= 2 || abSwitch.isChecked
        if (recorder.start(rate, twoChannels)) {
            recordButton.text = "■ STOP REKAM  00:00"
        } else {
            Toast.makeText(this, "Gagal membuat file rekaman", Toast.LENGTH_LONG).show()
        }
    }

    private fun onRecordingDone(location: String?) {
        recordButton.text = "● REKAM"
        if (location != null) {
            statusText.text = "Tersimpan: $location"
            Toast.makeText(this, "Rekaman tersimpan", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Rekaman gagal disimpan", Toast.LENGTH_LONG).show()
        }
    }

    private fun formatTime(ms: Long): String {
        val s = ms / 1000
        return String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
    }

    // ---------- Preset ----------

    private fun parseValues(csv: String?): FloatArray? {
        if (csv == null) return null
        val parts = csv.split(",")
        // Toleran terhadap versi lama (parameter lebih sedikit): sisanya tetap default.
        if (parts.size > values.size) return null
        val out = FloatArray(values.size) { Float.NaN }
        for (i in parts.indices) {
            out[i] = parts[i].toFloatOrNull() ?: return null
        }
        return out
    }

    private fun formatValues(): String =
        values.joinToString(",") { String.format(Locale.US, "%.4f", it) }

    private fun presetNames(): List<String> =
        prefs.all.keys.filter { it.startsWith("p_") }.map { it.removePrefix("p_") }.sorted()

    private fun refreshPresets(select: String? = null) {
        val names = presetNames()
        presetSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            if (names.isEmpty()) listOf("(belum ada preset)") else names
        )
        if (select != null) presetSpinner.setSelection(names.indexOf(select).coerceAtLeast(0))
    }

    private fun selectedPreset(): String? = presetNames().getOrNull(presetSpinner.selectedItemPosition)

    private fun onLoadClicked() {
        val name = selectedPreset()
        if (name == null) {
            Toast.makeText(this, "Belum ada preset tersimpan", Toast.LENGTH_SHORT).show()
            return
        }
        val vals = parseValues(prefs.getString("p_$name", null))
        if (vals == null) {
            Toast.makeText(this, "Preset rusak atau tidak cocok", Toast.LENGTH_SHORT).show()
            return
        }
        for (id in vals.indices) {
            if (id == AudioEngine.P_BYPASS || vals[id].isNaN()) continue
            setters[id]?.invoke(vals[id])
        }
        Toast.makeText(this, "Preset dimuat: $name", Toast.LENGTH_SHORT).show()
    }

    private fun onSaveClicked() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT
            hint = "Nama preset"
            setText(selectedPreset() ?: "Preset 1")
        }
        AlertDialog.Builder(this)
            .setTitle("Simpan preset")
            .setView(input)
            .setPositiveButton("Simpan") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) {
                    Toast.makeText(this, "Nama tidak boleh kosong", Toast.LENGTH_SHORT).show()
                } else {
                    prefs.edit().putString("p_$name", formatValues()).apply()
                    refreshPresets(name)
                    Toast.makeText(this, "Preset disimpan: $name", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun onDeleteClicked() {
        val name = selectedPreset()
        if (name == null) {
            Toast.makeText(this, "Belum ada preset tersimpan", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Hapus preset?")
            .setMessage(name)
            .setPositiveButton("Hapus") { _, _ ->
                prefs.edit().remove("p_$name").apply()
                refreshPresets()
                Toast.makeText(this, "Preset dihapus: $name", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------- UI helper ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(s: String, size: Float = 13f, color: Int = Color.rgb(170, 180, 190)) =
        TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            setPadding(0, dp(10), 0, dp(2))
        }

    private fun addSwitch(parent: LinearLayout, name: String, id: Int, def: Boolean) {
        val start = if (values[id].isNaN()) (if (def) 1f else 0f) else values[id]
        val sw = Switch(this).apply {
            text = name
            setTextColor(Color.WHITE)
        }
        fun push(on: Boolean) {
            values[id] = if (on) 1f else 0f
            AudioEngine.nativeSetParam(id, values[id])
        }
        sw.isChecked = start > 0.5f
        push(sw.isChecked)
        sw.setOnCheckedChangeListener { _, checked -> push(checked) }
        setters[id] = { v ->
            sw.isChecked = v > 0.5f
            push(v > 0.5f)
        }
        parent.addView(sw)
    }

    private fun addSlider(
        parent: LinearLayout, name: String, id: Int,
        lo: Float, hi: Float, def: Float, log: Boolean, unit: String, decimals: Int
    ) {
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(0, dp(8), 0, 0)
        }
        val bar = SeekBar(this).apply { max = 1000 }

        fun toValue(p: Int): Float =
            if (log) (lo * (hi / lo).toDouble().pow(p / 1000.0)).toFloat()
            else lo + (hi - lo) * p / 1000f

        fun toProgress(v: Float): Int {
            val p = if (log) 1000.0 * ln((v / lo).toDouble()) / ln((hi / lo).toDouble())
            else ((v - lo) / (hi - lo) * 1000f).toDouble()
            return p.toInt().coerceIn(0, 1000)
        }

        fun applyValue(v: Float) {
            values[id] = v
            tv.text = "$name: ${String.format(Locale.US, "%.${decimals}f", v)} $unit"
            AudioEngine.nativeSetParam(id, v)
        }

        val start = if (values[id].isNaN()) def else values[id]
        bar.progress = toProgress(start)
        applyValue(start)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                applyValue(toValue(progress))
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        setters[id] = { v ->
            bar.progress = toProgress(v)
            applyValue(v)  // nilai persis, menimpa pembulatan dari slider
        }
        parent.addView(tv)
        parent.addView(bar)
    }

    private fun deviceList(input: Boolean): List<AudioDeviceInfo?> {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val flag = if (input) AudioManager.GET_DEVICES_INPUTS else AudioManager.GET_DEVICES_OUTPUTS
        return listOf<AudioDeviceInfo?>(null) + am.getDevices(flag).toList()
    }

    private fun describe(d: AudioDeviceInfo?): String {
        if (d == null) return "Default"
        val kind = when (d.type) {
            AudioDeviceInfo.TYPE_BUILTIN_MIC -> "mic HP"
            AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "speaker HP"
            AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> "USB"
            AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "kabel"
            AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth"
            else -> "tipe ${d.type}"
        }
        return "${d.productName} ($kind)"
    }
}
