package com.example.dbxcomp

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.pow

/** Bar meter horizontal sederhana. */
class MeterView(
    context: Context,
    private val minValue: Float,
    private val maxValue: Float,
    private val baseColor: Int,
    private val redAbove: Float? = null
) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    var value: Float = minValue
        set(v) {
            field = v
            invalidate()
        }

    override fun onDraw(canvas: Canvas) {
        paint.color = Color.rgb(40, 46, 54)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        val frac = ((value - minValue) / (maxValue - minValue)).coerceIn(0f, 1f)
        paint.color =
            if (redAbove != null && value > redAbove) Color.rgb(230, 70, 60) else baseColor
        canvas.drawRect(0f, 0f, width * frac, height.toFloat(), paint)
    }
}

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private val meters = FloatArray(3)

    private lateinit var meterIn: MeterView
    private lateinit var meterOut: MeterView
    private lateinit var meterGr: MeterView
    private lateinit var startButton: Button
    private lateinit var inSpinner: Spinner
    private lateinit var outSpinner: Spinner

    private var inDevices: List<AudioDeviceInfo?> = emptyList()
    private var outDevices: List<AudioDeviceInfo?> = emptyList()
    private var running = false

    private val ticker = object : Runnable {
        override fun run() {
            AudioEngine.nativeGetMeters(meters)
            meterIn.value = max(meters[0], meterIn.value - 2f)
            meterOut.value = max(meters[1], meterOut.value - 2f)
            meterGr.value = max(meters[2], meterGr.value - 0.8f)
            if (running) handler.postDelayed(this, 33)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val pad = dp(16)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.rgb(16, 20, 24))
            addView(root)
        }
        setContentView(scroll)

        root.addView(label("DbxComp  |  Compressor + Limiter", 20f, Color.WHITE))
        root.addView(
            label(
                "Pakai headphone atau audio interface USB. Mic HP + speaker HP di ruangan " +
                    "yang sama akan menyebabkan feedback (howling). Bluetooth = latensi tinggi.",
                12f, Color.rgb(240, 180, 80)
            )
        )

        // Perangkat audio
        inDevices = deviceList(true)
        outDevices = deviceList(false)
        root.addView(label("Input"))
        inSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                inDevices.map { describe(it) }
            )
        }
        root.addView(inSpinner)
        root.addView(label("Output"))
        outSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                outDevices.map { describe(it) }
            )
        }
        root.addView(outSpinner)

        startButton = Button(this).apply { text = "START" }
        startButton.setOnClickListener { if (running) stopAudio() else requestAndStart() }
        root.addView(startButton)

        // Meter
        val h = dp(14)
        root.addView(label("Input level (dBFS)"))
        meterIn = MeterView(this, -60f, 0f, Color.rgb(60, 200, 120), -3f)
        root.addView(meterIn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h))
        root.addView(label("Gain reduction (dB)"))
        meterGr = MeterView(this, 0f, 20f, Color.rgb(240, 160, 40))
        root.addView(meterGr, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h))
        root.addView(label("Output level (dBFS)"))
        meterOut = MeterView(this, -60f, 0f, Color.rgb(60, 200, 120), -3f)
        root.addView(meterOut, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h))

        // Kontrol
        root.addView(label("COMPRESSOR", 15f, Color.WHITE))
        addSwitch(root, "Bypass compressor/limiter", AudioEngine.P_BYPASS, false)
        addSlider(root, "Input gain", AudioEngine.P_IN_GAIN, -12f, 24f, 0f, false, "dB", 1)
        addSlider(root, "Threshold", AudioEngine.P_THRESH, -60f, 0f, -20f, false, "dB", 1)
        addSlider(root, "Ratio", AudioEngine.P_RATIO, 1f, 20f, 4f, false, ": 1", 1)
        addSlider(root, "Attack", AudioEngine.P_ATTACK, 0.1f, 100f, 10f, true, "ms", 1)
        addSlider(root, "Release", AudioEngine.P_RELEASE, 10f, 2000f, 200f, true, "ms", 0)
        addSlider(root, "Knee (0 = hard)", AudioEngine.P_KNEE, 0f, 24f, 6f, false, "dB", 1)
        addSlider(root, "Makeup gain", AudioEngine.P_MAKEUP, 0f, 24f, 0f, false, "dB", 1)

        root.addView(label("LIMITER", 15f, Color.WHITE))
        addSwitch(root, "Limiter aktif", AudioEngine.P_LIM_ON, true)
        addSlider(root, "Ceiling", AudioEngine.P_CEIL, -12f, 0f, -1f, false, "dBFS", 1)
        addSlider(root, "Output gain", AudioEngine.P_OUT_GAIN, -24f, 12f, 0f, false, "dB", 1)
    }

    override fun onStop() {
        super.onStop()
        // Android membatasi mic di latar belakang, jadi hentikan dengan bersih.
        if (running) stopAudio()
    }

    // ---------- Audio ----------

    private fun requestAndStart() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            startAudio()
        } else {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            startAudio()
        } else {
            Toast.makeText(this, "Izin mikrofon diperlukan", Toast.LENGTH_LONG).show()
        }
    }

    private fun startAudio() {
        val inId = inDevices.getOrNull(inSpinner.selectedItemPosition)?.id ?: 0
        val outId = outDevices.getOrNull(outSpinner.selectedItemPosition)?.id ?: 0
        if (AudioEngine.nativeStart(inId, outId)) {
            running = true
            startButton.text = "STOP"
            handler.post(ticker)
        } else {
            Toast.makeText(this, "Gagal membuka perangkat audio", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopAudio() {
        AudioEngine.nativeStop()
        running = false
        startButton.text = "START"
    }

    // ---------- UI helper ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(s: String, size: Float = 13f, color: Int = Color.rgb(170, 180, 190)) =
        TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            setPadding(0, dp(10), 0, dp(2))
        }

    private fun addSwitch(parent: LinearLayout, name: String, id: Int, def: Boolean) {
        val sw = Switch(this).apply {
            text = name
            setTextColor(Color.WHITE)
            isChecked = def
        }
        AudioEngine.nativeSetParam(id, if (def) 1f else 0f)
        sw.setOnCheckedChangeListener { _, checked ->
            AudioEngine.nativeSetParam(id, if (checked) 1f else 0f)
        }
        parent.addView(sw)
    }

    private fun addSlider(
        parent: LinearLayout, name: String, id: Int,
        lo: Float, hi: Float, def: Float, log: Boolean, unit: String, decimals: Int
    ) {
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(0, dp(8), 0, 0)
        }
        val bar = SeekBar(this).apply { max = 1000 }

        fun toValue(p: Int): Float =
            if (log) (lo * (hi / lo).toDouble().pow(p / 1000.0)).toFloat()
            else lo + (hi - lo) * p / 1000f

        fun toProgress(v: Float): Int =
            if (log) (1000.0 * ln((v / lo).toDouble()) / ln((hi / lo).toDouble())).toInt()
            else ((v - lo) / (hi - lo) * 1000f).toInt()

        fun apply(v: Float) {
            tv.text = "$name: ${String.format(Locale.US, "%.${decimals}f", v)} $unit"
            AudioEngine.nativeSetParam(id, v)
        }

        bar.progress = toProgress(def)
        apply(def)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                apply(toValue(progress))
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        parent.addView(tv)
        parent.addView(bar)
    }

    private fun deviceList(input: Boolean): List<AudioDeviceInfo?> {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val flag = if (input) AudioManager.GET_DEVICES_INPUTS else AudioManager.GET_DEVICES_OUTPUTS
        return listOf<AudioDeviceInfo?>(null) + am.getDevices(flag).toList()
    }

    private fun describe(d: AudioDeviceInfo?): String {
        if (d == null) return "Default"
        val kind = when (d.type) {
            AudioDeviceInfo.TYPE_BUILTIN_MIC -> "mic HP"
            AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "speaker HP"
            AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> "USB"
            AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "kabel"
            AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth"
            else -> "tipe ${d.type}"
        }
        return "${d.productName} ($kind)"
    }
}
