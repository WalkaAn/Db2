package com.example.dbxcomp

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.Log
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

/**
 * Merekam hasil akhir (setelah compressor + limiter) ke file WAV 16-bit.
 * Android 10+: disimpan di Music/DbxComp (terlihat di aplikasi Files dan pemutar musik).
 * Android 9 ke bawah: di folder Music milik aplikasi.
 *
 * Mode A/B: stereo, kiri = suara asli (setelah input gain), kanan = hasil olahan,
 * jadi bisa dibandingkan langsung di editor audio.
 */
class WavRecorder(
    private val context: Context,
    private val onDone: (String?) -> Unit
) {
    private class Sink(val channel: FileChannel, val location: String, val close: () -> Unit)

    @Volatile
    var isRecording = false
        private set

    private val main = Handler(Looper.getMainLooper())
    private val frames = AtomicLong(0)
    private var sampleRate = 48000
    private var thread: Thread? = null

    val elapsedMs: Long get() = frames.get() * 1000L / sampleRate

    fun start(sampleRate: Int, stereoAB: Boolean): Boolean {
        if (isRecording || thread?.isAlive == true) return false
        this.sampleRate = if (sampleRate > 0) sampleRate else 48000
        frames.set(0)
        val sink = openSink() ?: return false
        val channels = if (stereoAB) 2 else 1
        val rate = this.sampleRate

        isRecording = true
        AudioEngine.nativeSetRecording(true)

        thread = Thread {
            var result: String? = null
            try {
                writeFully(sink.channel, wavHeader(rate, channels, 0L))
                val buf = FloatArray(8192)
                val bytes = ByteBuffer.allocate(buf.size * 2).order(ByteOrder.LITTLE_ENDIAN)
                var dataBytes = 0L
                while (true) {
                    val n = AudioEngine.nativeReadRecorded(buf)
                    if (n > 0) {
                        bytes.clear()
                        var i = 0
                        while (i + 1 < n) {
                            if (stereoAB) bytes.putShort(toPcm(buf[i]))  // asli
                            bytes.putShort(toPcm(buf[i + 1]))            // hasil
                            i += 2
                        }
                        bytes.flip()
                        dataBytes += bytes.limit()
                        writeFully(sink.channel, bytes)
                        frames.addAndGet((n / 2).toLong())
                    } else if (!isRecording) {
                        break
                    } else {
                        Thread.sleep(15)
                    }
                }
                // Tulis ulang header dengan ukuran akhir.
                sink.channel.position(0)
                writeFully(sink.channel, wavHeader(rate, channels, dataBytes))
                result = sink.location
            } catch (e: Exception) {
                Log.e("DbxComp", "Rekaman gagal", e)
            } finally {
                isRecording = false
                AudioEngine.nativeSetRecording(false)
                try {
                    sink.close()
                } catch (e: Exception) {
                    Log.e("DbxComp", "Gagal menutup file", e)
                    result = null
                }
                val r = result
                main.post { onDone(r) }
            }
        }.also { it.start() }
        return true
    }

    /** Berhenti merekam; file diselesaikan di thread latar lalu [onDone] dipanggil. */
    fun stop() {
        if (!isRecording) return
        isRecording = false
        AudioEngine.nativeSetRecording(false)
    }

    private fun openSink(): Sink? {
        val name = "DbxComp_" +
            SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".wav"
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val cv = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "audio/wav")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "Music/DbxComp")
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                val uri = resolver.insert(
                    MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), cv
                ) ?: return null
                val pfd = resolver.openFileDescriptor(uri, "rw") ?: return null
                val ch = ParcelFileDescriptor.AutoCloseOutputStream(pfd).channel
                Sink(ch, "Music/DbxComp/$name") {
                    ch.close()
                    val done = ContentValues().apply {
                        put(MediaStore.MediaColumns.IS_PENDING, 0)
                    }
                    resolver.update(uri, done, null, null)
                }
            } else {
                val dir = context.getExternalFilesDir(Environment.DIRECTORY_MUSIC)
                    ?: context.filesDir
                dir.mkdirs()
                val f = File(dir, name)
                val raf = RandomAccessFile(f, "rw")
                Sink(raf.channel, f.absolutePath) { raf.close() }
            }
        } catch (e: Exception) {
            Log.e("DbxComp", "Gagal membuat file rekaman", e)
            null
        }
    }

    private fun toPcm(x: Float): Short = (x.coerceIn(-1f, 1f) * 32767f).toInt().toShort()

    private fun writeFully(ch: FileChannel, bb: ByteBuffer) {
        while (bb.hasRemaining()) ch.write(bb)
    }

    private fun wavHeader(sampleRate: Int, channels: Int, dataBytes: Long): ByteBuffer {
        val bb = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray(Charsets.US_ASCII))
        bb.putInt((36 + dataBytes).toInt())
        bb.put("WAVE".toByteArray(Charsets.US_ASCII))
        bb.put("fmt ".toByteArray(Charsets.US_ASCII))
        bb.putInt(16)
        bb.putShort(1)  // PCM
        bb.putShort(channels.toShort())
        bb.putInt(sampleRate)
        bb.putInt(sampleRate * channels * 2)
        bb.putShort((channels * 2).toShort())
        bb.putShort(16)
        bb.put("data".toByteArray(Charsets.US_ASCII))
        bb.putInt(dataBytes.toInt())
        bb.flip()
        return bb
    }
}
