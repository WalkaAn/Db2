package com.example.dbxcomp

/** Jembatan JNI ke mesin audio native (Oboe). */
object AudioEngine {
    // ID parameter, harus sama dengan enum ParamId di audio_engine.cpp
    const val P_THRESH = 0
    const val P_RATIO = 1
    const val P_ATTACK = 2
    const val P_RELEASE = 3
    const val P_KNEE = 4
    const val P_MAKEUP = 5
    const val P_CEIL = 6
    const val P_LIM_ON = 7
    const val P_BYPASS = 8
    const val P_IN_GAIN = 9
    const val P_OUT_GAIN = 10
    const val P_LINK = 11

    init {
        System.loadLibrary("dbxcomp")
    }

    /** [stereo] = minta input 2 channel; kalau perangkat menolak, otomatis turun ke mono. */
    external fun nativeStart(inputDeviceId: Int, outputDeviceId: Int, stereo: Boolean): Boolean
    external fun nativeStop()
    external fun nativeSetParam(id: Int, value: Float)

    /** Mengisi [out] dengan: input peak dB, output peak dB, gain reduction dB (positif). */
    external fun nativeGetMeters(out: FloatArray)

    /** Aktif/nonaktifkan penangkapan audio (pasangan asli+hasil) ke ring buffer. */
    external fun nativeSetRecording(on: Boolean)

    /** Mengambil data rekaman terkumpul ke [out]; mengembalikan jumlah float (genap). */
    external fun nativeReadRecorded(out: FloatArray): Int

    external fun nativeGetSampleRate(): Int

    /** Jumlah channel input yang benar-benar diberikan perangkat (1 atau 2). */
    external fun nativeGetInputChannels(): Int
}
