# DbxComp

Compressor + limiter real-time untuk Android, terinspirasi perangkat dbx.
Mic / line-in -> compressor (RMS, soft knee) -> limiter -> output, dengan Oboe
(audio latensi rendah) dan meter gain reduction.

## Cara build di GitHub (tanpa Android Studio)

1. Buat repository baru di github.com.
2. Unggah isi proyek ini ke repo:
   - **Dari komputer:** ekstrak zip, lalu seret semua isinya (termasuk folder
     `.github`) ke halaman repo -> *Add file -> Upload files*.
   - **Dari HP:** unggah `DbxComp.zip` apa adanya (*Add file -> Upload files*),
     lalu *Add file -> Create new file*, namai `.github/workflows/build.yml`,
     tempel isi file `build.yml`, dan commit. Workflow akan mengekstrak zip sendiri.
3. Buka tab **Actions**. Build jalan otomatis setiap ada commit
   (atau klik *Run workflow*). Butuh sekitar 5-10 menit.
4. Setelah hijau, buka run-nya -> bagian **Artifacts** -> unduh `DbxComp-debug-apk`
   -> ekstrak -> pasang `app-debug.apk` di HP (izinkan "install dari sumber tidak dikenal").

## Catatan pemakaian

- Pakai **headphone** atau **audio interface USB**. Mic HP + speaker HP = feedback.
- Pilih perangkat input/output di dalam aplikasi. Untuk latensi terendah: interface USB
  atau headphone berkabel. Bluetooth biasanya 100 ms lebih.
- Aplikasi harus tetap di layar depan; Android membatasi mic di latar belakang,
  jadi audio berhenti otomatis saat aplikasi ditinggal.
- Mode input memakai `Unprocessed` supaya AGC/noise suppression bawaan HP mati.
- Limiter tanpa lookahead: puncak sangat cepat dipotong keras di ceiling sebagai
  pengaman, jadi bukan brickwall transparan setara hardware.

## Struktur

- `app/src/main/cpp/compressor.h` — algoritma compressor dan limiter
- `app/src/main/cpp/audio_engine.cpp` — stream duplex Oboe + JNI
- `app/src/main/java/.../MainActivity.kt` — UI (slider, meter, pilih perangkat)
