# DbxComp

Compressor + limiter real-time untuk Android, terinspirasi perangkat dbx.
Mic / line-in -> compressor (RMS, soft knee) -> limiter -> output, dengan Oboe
(audio latensi rendah) dan meter gain reduction.

## Cara build di GitHub (tanpa Android Studio)

1. Buat repository baru di github.com.
2. Unggah isi proyek ini ke repo:
   - **Dari komputer:** ekstrak zip, lalu seret semua isinya (termasuk folder
     `.github`) ke halaman repo -> *Add file -> Upload files*.
   - **Dari HP:** unggah `DbxComp.zip` apa adanya (*Add file -> Upload files*),
     lalu *Add file -> Create new file*, namai `.github/workflows/build.yml`,
     tempel isi file `build.yml`, dan commit. Workflow akan mengekstrak zip sendiri.
3. Buka tab **Actions**. Build jalan otomatis setiap ada commit
   (atau klik *Run workflow*). Butuh sekitar 5-10 menit.
4. Setelah hijau, buka run-nya -> bagian **Artifacts** -> unduh `DbxComp-debug-apk`
   -> ekstrak -> pasang `app-debug.apk` di HP (izinkan "install dari sumber tidak dikenal").

## Catatan pemakaian

- Pakai **headphone** atau **audio interface USB**. Mic HP + speaker HP = feedback.
- Pilih perangkat input/output di dalam aplikasi. Untuk latensi terendah: interface USB
  atau headphone berkabel. Bluetooth biasanya 100 ms lebih.
- Aplikasi harus tetap di layar depan; Android membatasi mic di latar belakang,
  jadi audio berhenti otomatis saat aplikasi ditinggal.
- Mode input memakai `Unprocessed` supaya AGC/noise suppression bawaan HP mati.
- Limiter tanpa lookahead: puncak sangat cepat dipotong keras di ceiling sebagai
  pengaman, jadi bukan brickwall transparan setara hardware.

## Preset dan rekam

- **Preset:** atur slider, tekan *Simpan*, beri nama. *Muat* memanggil kembali,
  *Hapus* membuang. Pengaturan terakhir otomatis kembali saat aplikasi dibuka
  (kecuali Bypass, yang selalu mati saat dibuka).
- **Rekam:** tekan START, lalu *● REKAM*. Yang direkam adalah hasil akhir setelah
  compressor + limiter, format WAV 16-bit. File ada di folder **Music/DbxComp**
  (Android 10+), terlihat di aplikasi Files dan pemutar musik. Android 9 ke bawah:
  folder Music milik aplikasi (`Android/data/com.example.dbxcomp/files/Music`).
- **Rekam A/B:** nyalakan switch-nya untuk membuat WAV stereo, kiri = suara asli,
  kanan = hasil olahan. Di editor audio, kiri vs kanan langsung bisa dibandingkan.

## Input stereo asli (L/R mandiri)

- Nyalakan switch **Input stereo** sebelum START. Aplikasi meminta input 2 channel
  (mode Camcorder, jalur yang dipakai kamera untuk dua mic HP) dan kiri/kanan diproses
  terpisah. Setelah START, teks status menunjukkan hasil sebenarnya: stereo asli atau
  mono. Kalau HP tidak memberi 2 channel, aplikasi otomatis turun ke mono.
- **Link L/R** (default hidup): kiri dan kanan memakai gain reduction yang sama
  (yang terbesar), supaya posisi suara tidak bergeser. Matikan kalau mau dua sisi
  dikompres sepenuhnya mandiri.
- Rekaman saat input stereo = WAV stereo (kiri dan kanan hasil olahan). Mode A/B hanya
  untuk input mono dan otomatis nonaktif saat input stereo.
- Interface USB dengan 2 input juga bisa memberi stereo asli.

## Struktur

- `app/src/main/cpp/compressor.h` — algoritma compressor dan limiter
- `app/src/main/cpp/audio_engine.cpp` — stream duplex Oboe + JNI
- `app/src/main/cpp/ring_buffer.h` — buffer lock-free untuk rekaman
- `app/src/main/java/.../WavRecorder.kt` — penulis file WAV
- `app/src/main/java/.../MainActivity.kt` — UI (slider, meter, pilih perangkat)
